# Muzyka Widget (Android)

Własny widżet w stylu odtwarzacza multimediów z ekranu blokady Androida.

- Okładka albumu jako tło, zaokrąglone narożniki i przyciemnienie.
- Tytuł, artysta, pasek postępu, poprzedni / pauza / następny.
- Preferuje Spotify, ale obsługuje też inne aktywne sesje Android MediaSession.
- Nie potrzebuje hasła Spotify ani dostępu do Internetu.
- Do pobierania stanu odtwarzania wymaga włączonego systemowego dostępu do powiadomień.
- Działa na Androidzie 8+; projekt docelowo przygotowany do Motoroli Android 14.

## Instalacja

Uruchom workflow w GitHub Actions, pobierz artefakt `Muzyka-Widget-APK`, rozpakuj i zainstaluj `app-debug.apk`. Włącz aplikacji dostęp do powiadomień. Dodaj widżet na pulpicie Motoroli.

**Uwaga:** systemowe ustawienie dostępu do powiadomień ma szeroki zakres. Kod aplikacji czyta tylko stan i metadane sesji multimediów; niczego nie przesyła do sieci. Widżet nie jest oryginalnym komponentem Android SystemUI.

Na niektórych odtwarzaczach okładka może nie być dostępna, a pasek postępu może odświeżać się z opóźnieniem do około 15 sekund. Sterowanie działa pod warunkiem istnienia aktywnej sesji odtwarzacza.
